﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Su_Final
{
    public partial class frmGame : Form
    {
        private string difficulty = "Easy";
        private int elapsedSeconds = 0;
        private int lives = 3;
        private int[,] solution = new int[9, 9];
        private int[,] puzzle = new int[9, 9];
        private int[,] currentBoard = new int[9, 9];
        private readonly Random random = new Random();
        private Button selectedButton = null;
        private bool gameFinished = false;
        private bool boardPrepared = false;
        private bool gameInitialized = false;
        private readonly Button[,] boardCells = new Button[9, 9];

        // Bảng màu: ô đề cố định luôn xanh biển nhạt.
        private static readonly Color FixedCellColor = Color.FromArgb(216, 236, 255);
        private static readonly Color EmptyCellColor = Color.White;
        private static readonly Color FilledCellColor = Color.FromArgb(232, 247, 239);
        private static readonly Color SelectedCellColor = Color.FromArgb(255, 239, 193);
        private static readonly Color PrimaryColor = Color.FromArgb(30, 91, 154);
        private static readonly Color GridColor = Color.FromArgb(191, 208, 226);
        private static readonly Color BlockBorderColor = Color.FromArgb(61, 94, 135);

        public frmGame()
        {
            InitializeComponent();
            ConfigureAppearance();
        }

        public frmGame(string difficulty) : this()
        {
            // Gán độ khó trước khi form hiển thị.
            // Việc tạo đề sẽ do OnShown thực hiện cho CẢ hai constructor.
            this.difficulty = string.IsNullOrWhiteSpace(difficulty) ? "Easy" : difficulty;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

            // Quan trọng: menu có thể gọi new frmGame() (không có tham số).
            // Chỉ tạo đề sau khi WinForms đã hoàn tất hiển thị/layout form.
            if (!gameInitialized)
            {
                gameInitialized = true;
                StartGame();
            }
        }

        private void StartGame()
        {
            gameTimer.Stop();
            gameFinished = false;
            selectedButton = null;
            elapsedSeconds = 0;
            lives = 3;

            // Dùng lại các nút btn00 ... btn88 trong Designer, bố trí thành
            // 9 khối 3x3. Chỉ dựng giao diện một lần, kể cả khi chơi lại.
            PrepareSudokuBoard();
            StyleNumberButtons();

            GenerateSudoku();
            RemoveNumbers(GetEmptyCells());
            LoadPuzzle(puzzle);
            // Khi bắt đầu ván mới, ô đề sẽ có số và nền xanh biển nhạt.
            // Đưa bảng lên phía trước nếu có control khác che mất.
            if (boardCells[0, 0] != null &&
                boardCells[0, 0].Parent != null &&
                boardCells[0, 0].Parent.Parent != null)
            {
                boardCells[0, 0].Parent.Parent.BringToFront();
            }

            lblMode.Text = "Chế độ: " + GetDifficultyDisplayName();
            UpdateLivesDisplay();
            lblTime.Text = "Thời gian: 00:00";
            gameTimer.Start();
        }

        private void ConfigureAppearance()
        {
            BackColor = Color.FromArgb(245, 249, 253);

            lblMode.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
            lblMode.ForeColor = PrimaryColor;
            lblMode.AutoSize = true;

            lblTime.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
            lblTime.ForeColor = Color.FromArgb(50, 65, 84);
            lblTime.AutoSize = true;

            lblLives.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
            lblLives.ForeColor = Color.FromArgb(203, 69, 95);
            lblLives.AutoSize = true;
        }

        private void PrepareSudokuBoard()
        {
            if (boardPrepared)
                return;

            Button[,] cells = new Button[9, 9];
            List<Button> existingCells = new List<Button>();

            for (int row = 0; row < 9; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    string name = "btn" + row + col;
                    Button btn = Controls.Find(name, true).OfType<Button>().FirstOrDefault();
                    cells[row, col] = btn;
                    if (btn != null)
                        existingCells.Add(btn);
                }
            }

            // Đặt bảng đúng khu vực bàn chơi cũ (trong trường hợp Designer
            // đã bố trí bảng Sudoku). Nếu chưa có, tạo bảng tại vị trí mặc định.
            Control boardHost = this;
            Rectangle oldBounds = Rectangle.Empty;
            if (existingCells.Count > 0)
            {
                Control commonParent = existingCells[0].Parent;
                if (commonParent != null && !(commonParent is TableLayoutPanel) &&
                    existingCells.All(b => b.Parent == commonParent))
                {
                    boardHost = commonParent;
                }

                foreach (Button btn in existingCells)
                {
                    Rectangle rect = boardHost.RectangleToClient(
                        btn.RectangleToScreen(btn.ClientRectangle));
                    oldBounds = oldBounds.IsEmpty ? rect : Rectangle.Union(oldBounds, rect);
                }
            }

            Point boardLocation = existingCells.Count > 0
                ? oldBounds.Location
                : new Point(24, 95);

            int originalSize = existingCells.Count > 0
                ? Math.Min(oldBounds.Width, oldBounds.Height)
                : 440;

            // Tối thiểu 32px mỗi ô, tối đa 54px để số dễ đọc.
            int cellSize = Math.Max(32, Math.Min(54, (originalSize - 14) / 9));
            const int blockGap = 4;
            const int outsidePadding = 3;
            int blockSize = cellSize * 3;
            int boardSize = blockSize * 3 + blockGap * 2 + outsidePadding * 2;

            Panel boardPanel = new Panel
            {
                Name = "pnlSudokuBoard",
                Location = boardLocation,
                Size = new Size(boardSize, boardSize),
                BackColor = BlockBorderColor,
                Margin = Padding.Empty
            };
            boardHost.Controls.Add(boardPanel);

            // 3 x 3 khối, mỗi khối chứa 3 x 3 ô = 81 ô Sudoku.
            for (int blockRow = 0; blockRow < 3; blockRow++)
            {
                for (int blockCol = 0; blockCol < 3; blockCol++)
                {
                    Panel block = new Panel
                    {
                        Name = "pnlBlock" + blockRow + blockCol,
                        Location = new Point(
                            outsidePadding + blockCol * (blockSize + blockGap),
                            outsidePadding + blockRow * (blockSize + blockGap)),
                        Size = new Size(blockSize, blockSize),
                        BackColor = GridColor,
                        Margin = Padding.Empty
                    };
                    boardPanel.Controls.Add(block);

                    for (int localRow = 0; localRow < 3; localRow++)
                    {
                        for (int localCol = 0; localCol < 3; localCol++)
                        {
                            int row = blockRow * 3 + localRow;
                            int col = blockCol * 3 + localCol;
                            Button btn = cells[row, col];
                            if (btn == null)
                            {
                                btn = new Button { Name = "btn" + row + col };
                                cells[row, col] = btn;
                            }

                            btn.Dock = DockStyle.None;
                            btn.AutoSize = false;
                            btn.MinimumSize = Size.Empty;
                            btn.MaximumSize = Size.Empty;
                            btn.Anchor = AnchorStyles.Top | AnchorStyles.Left;
                            btn.Margin = Padding.Empty;
                            btn.Size = new Size(cellSize, cellSize);
                            btn.Location = new Point(localCol * cellSize, localRow * cellSize);
                            btn.Font = new Font("Segoe UI", cellSize >= 42 ? 16f : 13f,
                                FontStyle.Bold);
                            btn.TextAlign = ContentAlignment.MiddleCenter;
                            btn.FlatStyle = FlatStyle.Flat;
                            btn.FlatAppearance.BorderColor = GridColor;
                            btn.FlatAppearance.BorderSize = 1;
                            btn.UseVisualStyleBackColor = false;
                            btn.TabStop = false;

                            // Tránh gọi sự kiện hai lần nếu Designer đã gán sẵn.
                            btn.Click -= btnCell_Click;
                            btn.Click += btnCell_Click;
                            block.Controls.Add(btn);
                            boardCells[row, col] = btn;
                        }
                    }
                }
            }

            boardPanel.BringToFront();
            boardPrepared = true;

            // Không để bàn cờ mới bị cắt khi Designer dùng cửa sổ quá nhỏ.
            if (boardHost == this)
            {
                int requiredWidth = boardPanel.Right + 22;
                int requiredHeight = boardPanel.Bottom + 22;
                ClientSize = new Size(
                    Math.Max(ClientSize.Width, requiredWidth),
                    Math.Max(ClientSize.Height, requiredHeight));
            }
            else if (boardHost is ScrollableControl)
            {
                ScrollableControl host = (ScrollableControl)boardHost;
                if (boardPanel.Right > host.ClientSize.Width ||
                    boardPanel.Bottom > host.ClientSize.Height)
                {
                    host.AutoScroll = true;
                }
            }
        }

        private IEnumerable<Control> GetAllControls(Control parent)
        {
            foreach (Control ctrl in parent.Controls)
            {
                yield return ctrl;
                foreach (Control child in GetAllControls(ctrl))
                    yield return child;
            }
        }

        private void StyleNumberButtons()
        {
            foreach (Button btn in GetAllControls(this).OfType<Button>())
            {
                // Không chỉnh nút của 81 ô Sudoku.
                if (IsCellName(btn.Name))
                    continue;

                int number;
                if (!int.TryParse(btn.Text.Trim(), out number) || number < 1 || number > 9)
                    continue;

                btn.Font = new Font("Segoe UI", 12f, FontStyle.Bold);
                btn.ForeColor = PrimaryColor;
                btn.BackColor = Color.FromArgb(227, 240, 253);
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderColor = Color.FromArgb(167, 200, 231);
                btn.FlatAppearance.BorderSize = 1;
                btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(206, 228, 249);
                btn.UseVisualStyleBackColor = false;
                btn.Cursor = Cursors.Hand;
                btn.Click -= btnNumber_Click;
                btn.Click += btnNumber_Click;
            }
        }

        private bool IsCellName(string name)
        {
            return name != null && name.Length == 5 &&
                   name.StartsWith("btn", StringComparison.Ordinal) &&
                   name[3] >= '0' && name[3] <= '8' &&
                   name[4] >= '0' && name[4] <= '8';
        }

        private Button FindCell(int row, int col)
        {
            // Dùng trực tiếp 81 nút vừa dựng, tránh tìm nhầm nút trong Designer.
            return boardCells[row, col];
        }

        private void StyleCell(Button btn, int row, int col, bool selected)
        {
            bool isFixed = puzzle[row, col] != 0;
            Color baseColor = isFixed ? FixedCellColor :
                (currentBoard[row, col] != 0 ? FilledCellColor : EmptyCellColor);

            btn.Enabled = true; // Giữ màu chữ sáng rõ, không làm nút bị xám.
            btn.BackColor = selected ? SelectedCellColor : baseColor;
            btn.ForeColor = isFixed ? Color.FromArgb(28, 74, 124) :
                Color.FromArgb(35, 63, 84);
            btn.Cursor = (isFixed || currentBoard[row, col] != 0)
                ? Cursors.Default : Cursors.Hand;
            btn.FlatAppearance.MouseOverBackColor =
                (isFixed || currentBoard[row, col] != 0) ? baseColor :
                Color.FromArgb(234, 246, 255);
            btn.FlatAppearance.MouseDownBackColor = selected ? SelectedCellColor : baseColor;
        }

        private void UpdateLivesDisplay()
        {
            if (lives == 3)
                lblLives.Text = "Mạng: ♥ ♥ ♥";
            else if (lives == 2)
                lblLives.Text = "Mạng: ♥ ♥ ♡";
            else if (lives == 1)
                lblLives.Text = "Mạng: ♥ ♡ ♡";
            else
                lblLives.Text = "Mạng: ♡ ♡ ♡";
        }

        private string GetDifficultyDisplayName()
        {
            switch (difficulty)
            {
                case "Easy": return "Dễ";
                case "Medium": return "Trung bình";
                case "Hard": return "Khó";
                default: return "Dễ";
            }
        }

        private void GenerateSudoku()
        {
            solution = new int[9, 9];
            puzzle = new int[9, 9];
            currentBoard = new int[9, 9];

            FillBoard(solution);
            Array.Copy(solution, puzzle, solution.Length);
        }

        private bool FillBoard(int[,] board)
        {
            for (int row = 0; row < 9; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    if (board[row, col] == 0)
                    {
                        List<int> numbers = Enumerable.Range(1, 9).ToList();
                        Shuffle(numbers);

                        foreach (int num in numbers)
                        {
                            if (IsValid(board, row, col, num))
                            {
                                board[row, col] = num;
                                if (FillBoard(board))
                                    return true;
                                board[row, col] = 0;
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }

        private void Shuffle(List<int> numbers)
        {
            for (int i = numbers.Count - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                int temp = numbers[i];
                numbers[i] = numbers[j];
                numbers[j] = temp;
            }
        }

        private bool IsValid(int[,] board, int row, int col, int num)
        {
            for (int c = 0; c < 9; c++)
                if (board[row, c] == num) return false;

            for (int r = 0; r < 9; r++)
                if (board[r, col] == num) return false;

            int startRow = row - row % 3;
            int startCol = col - col % 3;
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 3; c++)
                    if (board[startRow + r, startCol + c] == num) return false;

            return true;
        }

        private int GetEmptyCells()
        {
            switch (difficulty)
            {
                case "Easy": return 40;
                case "Medium": return 50;
                case "Hard": return 58;
                default: return 40;
            }
        }

        private void RemoveNumbers(int emptyCells)
        {
            List<int> positions = Enumerable.Range(0, 81).ToList();
            Shuffle(positions);

            for (int i = 0; i < Math.Min(emptyCells, 81); i++)
            {
                int position = positions[i];
                puzzle[position / 9, position % 9] = 0;
            }
        }

        private void LoadPuzzle(int[,] newPuzzle)
        {
            for (int row = 0; row < 9; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    currentBoard[row, col] = newPuzzle[row, col];
                    Button btn = FindCell(row, col);
                    if (btn == null) continue;

                    btn.Text = newPuzzle[row, col] == 0 ? "" : newPuzzle[row, col].ToString();
                    StyleCell(btn, row, col, false);
                }
            }
        }

        private void btnCell_Click(object sender, EventArgs e)
        {
            if (gameFinished) return;
            Button btn = sender as Button;
            if (btn == null || !IsCellName(btn.Name)) return;

            int row = btn.Name[3] - '0';
            int col = btn.Name[4] - '0';

            // Ô đề cho sẵn hoặc ô đã điền đúng đều không thể thay đổi.
            if (puzzle[row, col] != 0 || currentBoard[row, col] != 0)
                return;

            if (selectedButton != null && IsCellName(selectedButton.Name))
            {
                int oldRow = selectedButton.Name[3] - '0';
                int oldCol = selectedButton.Name[4] - '0';
                StyleCell(selectedButton, oldRow, oldCol, false);
            }

            selectedButton = btn;
            StyleCell(btn, row, col, true);
        }

        private void btnNumber_Click(object sender, EventArgs e)
        {
            if (gameFinished) return;
            if (selectedButton == null)
            {
                MessageBox.Show(this, "Hãy chọn một ô trống trước!", "Sudoku",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Button btnNumber = sender as Button;
            int value;
            if (btnNumber == null || !int.TryParse(btnNumber.Text.Trim(), out value) ||
                value < 1 || value > 9)
                return;

            int row = selectedButton.Name[3] - '0';
            int col = selectedButton.Name[4] - '0';
            if (puzzle[row, col] != 0 || currentBoard[row, col] != 0)
                return;

            if (value != solution[row, col])
            {
                lives--;
                UpdateLivesDisplay();
                if (lives <= 0)
                {
                    FinishGame(false);
                }
                else
                {
                    MessageBox.Show(this,
                        "Chưa đúng! Bạn còn " + lives + " mạng. Hãy thử lại nhé!",
                        "Sai đáp án", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                return;
            }

            currentBoard[row, col] = value;
            selectedButton.Text = value.ToString();
            StyleCell(selectedButton, row, col, false);
            selectedButton = null;

            // Kiểm tra ngay sau mỗi lần nhập đúng, không cần nút Nộp bài.
            if (IsPuzzleCompleted())
                FinishGame(true);
        }

        private bool IsPuzzleCompleted()
        {
            for (int row = 0; row < 9; row++)
                for (int col = 0; col < 9; col++)
                    if (currentBoard[row, col] != solution[row, col])
                        return false;
            return true;
        }

        private void FinishGame(bool won)
        {
            if (gameFinished) return;
            gameFinished = true;
            gameTimer.Stop();
            selectedButton = null;

            DialogResult choice = ShowEndGameDialog(won);
            if (choice == DialogResult.Retry)
                StartGame();
            else
                ReturnToMainMenu();
        }

        private DialogResult ShowEndGameDialog(bool won)
        {
            using (Form dialog = new Form())
            {
                dialog.Text = won ? "Chiến thắng Sudoku" : "Kết thúc trò chơi";
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ControlBox = false;
                dialog.ShowInTaskbar = false;
                dialog.BackColor = Color.White;
                dialog.ClientSize = new Size(440, 236);

                Label title = new Label
                {
                    Text = won ? "🎉 CHÚC MỪNG CHIẾN THẮNG!" : "BẠN ĐÃ HẾT MẠNG!",
                    Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                    ForeColor = won ? Color.FromArgb(34, 126, 96) :
                        Color.FromArgb(193, 69, 83),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Location = new Point(18, 27),
                    Size = new Size(404, 42)
                };

                Label description = new Label
                {
                    Text = won
                        ? "Bạn đã giải đúng toàn bộ bảng Sudoku!\n" +
                          "Thời gian: " + (elapsedSeconds / 60).ToString("D2") + ":" +
                          (elapsedSeconds % 60).ToString("D2") +
                          "    •    Mạng còn lại: " + lives
                        : "Đừng bỏ cuộc, bạn có thể thử một ván mới!",
                    Font = new Font("Segoe UI", 10.5f, FontStyle.Regular),
                    ForeColor = Color.FromArgb(68, 84, 101),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Location = new Point(22, 83),
                    Size = new Size(396, 58)
                };

                Button retry = new Button
                {
                    Text = "Thử lại",
                    Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                    ForeColor = Color.White,
                    BackColor = PrimaryColor,
                    FlatStyle = FlatStyle.Flat,
                    UseVisualStyleBackColor = false,
                    Cursor = Cursors.Hand,
                    Location = new Point(43, 161),
                    Size = new Size(166, 48),
                    DialogResult = DialogResult.Retry
                };
                retry.FlatAppearance.BorderSize = 0;
                retry.FlatAppearance.MouseOverBackColor = Color.FromArgb(41, 111, 180);

                Button menu = new Button
                {
                    Text = "Về menu chính",
                    Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                    ForeColor = PrimaryColor,
                    BackColor = Color.FromArgb(231, 241, 251),
                    FlatStyle = FlatStyle.Flat,
                    UseVisualStyleBackColor = false,
                    Cursor = Cursors.Hand,
                    Location = new Point(231, 161),
                    Size = new Size(166, 48),
                    DialogResult = DialogResult.No
                };
                menu.FlatAppearance.BorderColor = Color.FromArgb(180, 208, 235);
                menu.FlatAppearance.BorderSize = 1;
                menu.FlatAppearance.MouseOverBackColor = Color.FromArgb(212, 232, 251);

                dialog.Controls.Add(title);
                dialog.Controls.Add(description);
                dialog.Controls.Add(retry);
                dialog.Controls.Add(menu);
                dialog.AcceptButton = retry;
                dialog.CancelButton = menu;

                return dialog.ShowDialog(this);
            }
        }

        private void ReturnToMainMenu()
        {
            // Nếu menu đã mở (và bị ẩn khi vào game), hiện lại menu đó.
            // Không phụ thuộc tên lớp Form menu trong dự án.
            Form menuForm = Owner;
            if (menuForm == null || menuForm.IsDisposed)
            {
                menuForm = Application.OpenForms.Cast<Form>()
                    .FirstOrDefault(form => form != this && !form.IsDisposed && !form.Visible);
            }
            if (menuForm == null)
            {
                menuForm = Application.OpenForms.Cast<Form>()
                    .FirstOrDefault(form => form != this && !form.IsDisposed);
            }

            if (menuForm != null)
            {
                menuForm.Show();
                menuForm.WindowState = FormWindowState.Normal;
                menuForm.BringToFront();
            }
            Close();
        }

        private void gameTimer_Tick(object sender, EventArgs e)
        {
            if (gameFinished) return;
            elapsedSeconds++;
            lblTime.Text = "Thời gian: " +
                (elapsedSeconds / 60).ToString("D2") + ":" +
                (elapsedSeconds % 60).ToString("D2");
        }
    }
}

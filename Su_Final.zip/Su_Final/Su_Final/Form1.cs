﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Su_Final
{
    public partial class frmSudoku : Form
    {
        public frmSudoku()
        {
            InitializeComponent();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            using (frmDifficulty difficultyForm = new frmDifficulty())
            {
                if (difficultyForm.ShowDialog() == DialogResult.OK)
                {
                    this.Hide();

                    using (frmGame game = new frmGame(difficultyForm.SelectedDifficulty))
                    {
                        game.ShowDialog();
                    }

                    this.Show();
                }
            }
        }
    }
}

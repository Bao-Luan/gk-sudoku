﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Su_Final
{
    public partial class frmDifficulty : Form
    {
        public string SelectedDifficulty { get; private set; }
        public frmDifficulty()
        {
            InitializeComponent();
        }
        private void btnEasy_Click(object sender, EventArgs e)
        {
            SelectedDifficulty = "Easy";
            DialogResult = DialogResult.OK;
        }

        private void btnMedium_Click(object sender, EventArgs e)
        {
            SelectedDifficulty = "Medium";
            DialogResult = DialogResult.OK;
        }

        private void btnHard_Click(object sender, EventArgs e)
        {
            SelectedDifficulty = "Hard";
            DialogResult = DialogResult.OK;
        }
    }
}

﻿namespace Su_Final
{
    partial class frmGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tblBox00 = new System.Windows.Forms.TableLayoutPanel();
            this.btn00 = new System.Windows.Forms.Button();
            this.btn01 = new System.Windows.Forms.Button();
            this.btn02 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn20 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn22 = new System.Windows.Forms.Button();
            this.tblBox01 = new System.Windows.Forms.TableLayoutPanel();
            this.btn23 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn03 = new System.Windows.Forms.Button();
            this.btn04 = new System.Windows.Forms.Button();
            this.btn05 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn25 = new System.Windows.Forms.Button();
            this.btn24 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.tblBox02 = new System.Windows.Forms.TableLayoutPanel();
            this.btn06 = new System.Windows.Forms.Button();
            this.btn07 = new System.Windows.Forms.Button();
            this.btn08 = new System.Windows.Forms.Button();
            this.btn18 = new System.Windows.Forms.Button();
            this.btn28 = new System.Windows.Forms.Button();
            this.btn27 = new System.Windows.Forms.Button();
            this.btn26 = new System.Windows.Forms.Button();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn17 = new System.Windows.Forms.Button();
            this.tblBox10 = new System.Windows.Forms.TableLayoutPanel();
            this.btn30 = new System.Windows.Forms.Button();
            this.btn52 = new System.Windows.Forms.Button();
            this.btn32 = new System.Windows.Forms.Button();
            this.btn31 = new System.Windows.Forms.Button();
            this.btn41 = new System.Windows.Forms.Button();
            this.btn40 = new System.Windows.Forms.Button();
            this.btn50 = new System.Windows.Forms.Button();
            this.btn51 = new System.Windows.Forms.Button();
            this.btn42 = new System.Windows.Forms.Button();
            this.tblBox20 = new System.Windows.Forms.TableLayoutPanel();
            this.btn82 = new System.Windows.Forms.Button();
            this.btn81 = new System.Windows.Forms.Button();
            this.btn80 = new System.Windows.Forms.Button();
            this.btn70 = new System.Windows.Forms.Button();
            this.btn60 = new System.Windows.Forms.Button();
            this.btn61 = new System.Windows.Forms.Button();
            this.btn62 = new System.Windows.Forms.Button();
            this.btn72 = new System.Windows.Forms.Button();
            this.btn71 = new System.Windows.Forms.Button();
            this.tblBox11 = new System.Windows.Forms.TableLayoutPanel();
            this.btn53 = new System.Windows.Forms.Button();
            this.btn33 = new System.Windows.Forms.Button();
            this.btn43 = new System.Windows.Forms.Button();
            this.btn34 = new System.Windows.Forms.Button();
            this.btn35 = new System.Windows.Forms.Button();
            this.btn45 = new System.Windows.Forms.Button();
            this.btn44 = new System.Windows.Forms.Button();
            this.btn54 = new System.Windows.Forms.Button();
            this.btn55 = new System.Windows.Forms.Button();
            this.tblBox12 = new System.Windows.Forms.TableLayoutPanel();
            this.btn38 = new System.Windows.Forms.Button();
            this.btn48 = new System.Windows.Forms.Button();
            this.btn58 = new System.Windows.Forms.Button();
            this.btn57 = new System.Windows.Forms.Button();
            this.btn56 = new System.Windows.Forms.Button();
            this.btn46 = new System.Windows.Forms.Button();
            this.btn36 = new System.Windows.Forms.Button();
            this.btn37 = new System.Windows.Forms.Button();
            this.btn47 = new System.Windows.Forms.Button();
            this.tblBox21 = new System.Windows.Forms.TableLayoutPanel();
            this.btn64 = new System.Windows.Forms.Button();
            this.btn63 = new System.Windows.Forms.Button();
            this.btn65 = new System.Windows.Forms.Button();
            this.btn75 = new System.Windows.Forms.Button();
            this.btn85 = new System.Windows.Forms.Button();
            this.btn84 = new System.Windows.Forms.Button();
            this.btn74 = new System.Windows.Forms.Button();
            this.btn73 = new System.Windows.Forms.Button();
            this.btn83 = new System.Windows.Forms.Button();
            this.tblBox22 = new System.Windows.Forms.TableLayoutPanel();
            this.btn76 = new System.Windows.Forms.Button();
            this.btn86 = new System.Windows.Forms.Button();
            this.btn78 = new System.Windows.Forms.Button();
            this.btn66 = new System.Windows.Forms.Button();
            this.btn67 = new System.Windows.Forms.Button();
            this.btn68 = new System.Windows.Forms.Button();
            this.btn77 = new System.Windows.Forms.Button();
            this.btn87 = new System.Windows.Forms.Button();
            this.btn88 = new System.Windows.Forms.Button();
            this.pnlNumbers = new System.Windows.Forms.Panel();
            this.tblNumbers = new System.Windows.Forms.TableLayoutPanel();
            this.btnNumber1 = new System.Windows.Forms.Button();
            this.btnNumber2 = new System.Windows.Forms.Button();
            this.btnNumber3 = new System.Windows.Forms.Button();
            this.btnNumber4 = new System.Windows.Forms.Button();
            this.btnNumber5 = new System.Windows.Forms.Button();
            this.btnNumber6 = new System.Windows.Forms.Button();
            this.btnNumber7 = new System.Windows.Forms.Button();
            this.btnNumber8 = new System.Windows.Forms.Button();
            this.btnNumber9 = new System.Windows.Forms.Button();
            this.lblMode = new System.Windows.Forms.Label();
            this.lblLives = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tblBox00.SuspendLayout();
            this.tblBox01.SuspendLayout();
            this.tblBox02.SuspendLayout();
            this.tblBox10.SuspendLayout();
            this.tblBox20.SuspendLayout();
            this.tblBox11.SuspendLayout();
            this.tblBox12.SuspendLayout();
            this.tblBox21.SuspendLayout();
            this.tblBox22.SuspendLayout();
            this.pnlNumbers.SuspendLayout();
            this.tblNumbers.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblBox00
            // 
            this.tblBox00.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox00.ColumnCount = 3;
            this.tblBox00.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox00.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox00.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox00.Controls.Add(this.btn00, 0, 0);
            this.tblBox00.Controls.Add(this.btn01, 1, 0);
            this.tblBox00.Controls.Add(this.btn02, 2, 0);
            this.tblBox00.Controls.Add(this.btn12, 2, 1);
            this.tblBox00.Controls.Add(this.btn11, 1, 1);
            this.tblBox00.Controls.Add(this.btn10, 0, 1);
            this.tblBox00.Controls.Add(this.btn20, 0, 2);
            this.tblBox00.Controls.Add(this.btn21, 1, 2);
            this.tblBox00.Controls.Add(this.btn22, 2, 2);
            this.tblBox00.Location = new System.Drawing.Point(3, 619);
            this.tblBox00.Name = "tblBox00";
            this.tblBox00.RowCount = 3;
            this.tblBox00.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox00.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox00.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox00.Size = new System.Drawing.Size(192, 14);
            this.tblBox00.TabIndex = 0;
            // 
            // btn00
            // 
            this.btn00.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn00.Location = new System.Drawing.Point(4, 4);
            this.btn00.Name = "btn00";
            this.btn00.Size = new System.Drawing.Size(56, 1);
            this.btn00.TabIndex = 0;
            this.btn00.UseVisualStyleBackColor = true;
            this.btn00.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn01
            // 
            this.btn01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn01.Location = new System.Drawing.Point(67, 4);
            this.btn01.Name = "btn01";
            this.btn01.Size = new System.Drawing.Size(56, 1);
            this.btn01.TabIndex = 0;
            this.btn01.UseVisualStyleBackColor = true;
            this.btn01.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn02
            // 
            this.btn02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn02.Location = new System.Drawing.Point(130, 4);
            this.btn02.Name = "btn02";
            this.btn02.Size = new System.Drawing.Size(58, 1);
            this.btn02.TabIndex = 0;
            this.btn02.UseVisualStyleBackColor = true;
            this.btn02.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn12
            // 
            this.btn12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn12.Location = new System.Drawing.Point(130, 8);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(58, 1);
            this.btn12.TabIndex = 0;
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn11
            // 
            this.btn11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn11.Location = new System.Drawing.Point(67, 8);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(56, 1);
            this.btn11.TabIndex = 0;
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn10
            // 
            this.btn10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn10.Location = new System.Drawing.Point(4, 8);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(56, 1);
            this.btn10.TabIndex = 0;
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn20
            // 
            this.btn20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn20.Location = new System.Drawing.Point(4, 12);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(56, 1);
            this.btn20.TabIndex = 0;
            this.btn20.UseVisualStyleBackColor = true;
            this.btn20.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn21
            // 
            this.btn21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn21.Location = new System.Drawing.Point(67, 12);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(56, 1);
            this.btn21.TabIndex = 0;
            this.btn21.UseVisualStyleBackColor = true;
            this.btn21.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn22
            // 
            this.btn22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn22.Location = new System.Drawing.Point(130, 12);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(58, 1);
            this.btn22.TabIndex = 0;
            this.btn22.UseVisualStyleBackColor = true;
            this.btn22.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox01
            // 
            this.tblBox01.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox01.ColumnCount = 3;
            this.tblBox01.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox01.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox01.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox01.Controls.Add(this.btn23, 0, 2);
            this.tblBox01.Controls.Add(this.btn13, 0, 1);
            this.tblBox01.Controls.Add(this.btn03, 0, 0);
            this.tblBox01.Controls.Add(this.btn04, 1, 0);
            this.tblBox01.Controls.Add(this.btn05, 2, 0);
            this.tblBox01.Controls.Add(this.btn15, 2, 1);
            this.tblBox01.Controls.Add(this.btn25, 2, 2);
            this.tblBox01.Controls.Add(this.btn24, 1, 2);
            this.tblBox01.Controls.Add(this.btn14, 1, 1);
            this.tblBox01.Location = new System.Drawing.Point(3, 251);
            this.tblBox01.Name = "tblBox01";
            this.tblBox01.RowCount = 3;
            this.tblBox01.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox01.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox01.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox01.Size = new System.Drawing.Size(192, 192);
            this.tblBox01.TabIndex = 0;
            // 
            // btn23
            // 
            this.btn23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn23.Location = new System.Drawing.Point(4, 130);
            this.btn23.Name = "btn23";
            this.btn23.Size = new System.Drawing.Size(56, 58);
            this.btn23.TabIndex = 0;
            this.btn23.UseVisualStyleBackColor = true;
            this.btn23.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn13
            // 
            this.btn13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn13.Location = new System.Drawing.Point(4, 67);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(56, 56);
            this.btn13.TabIndex = 0;
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn03
            // 
            this.btn03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn03.Location = new System.Drawing.Point(4, 4);
            this.btn03.Name = "btn03";
            this.btn03.Size = new System.Drawing.Size(56, 56);
            this.btn03.TabIndex = 0;
            this.btn03.UseVisualStyleBackColor = true;
            this.btn03.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn04
            // 
            this.btn04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn04.Location = new System.Drawing.Point(67, 4);
            this.btn04.Name = "btn04";
            this.btn04.Size = new System.Drawing.Size(56, 56);
            this.btn04.TabIndex = 0;
            this.btn04.UseVisualStyleBackColor = true;
            this.btn04.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn05
            // 
            this.btn05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn05.Location = new System.Drawing.Point(130, 4);
            this.btn05.Name = "btn05";
            this.btn05.Size = new System.Drawing.Size(58, 56);
            this.btn05.TabIndex = 0;
            this.btn05.UseVisualStyleBackColor = true;
            this.btn05.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn15
            // 
            this.btn15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn15.Location = new System.Drawing.Point(130, 67);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(58, 56);
            this.btn15.TabIndex = 0;
            this.btn15.UseVisualStyleBackColor = true;
            this.btn15.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn25
            // 
            this.btn25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn25.Location = new System.Drawing.Point(130, 130);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(58, 58);
            this.btn25.TabIndex = 0;
            this.btn25.UseVisualStyleBackColor = true;
            this.btn25.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn24
            // 
            this.btn24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn24.Location = new System.Drawing.Point(67, 130);
            this.btn24.Name = "btn24";
            this.btn24.Size = new System.Drawing.Size(56, 58);
            this.btn24.TabIndex = 0;
            this.btn24.UseVisualStyleBackColor = true;
            this.btn24.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn14
            // 
            this.btn14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn14.Location = new System.Drawing.Point(67, 67);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(56, 56);
            this.btn14.TabIndex = 0;
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox02
            // 
            this.tblBox02.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox02.ColumnCount = 3;
            this.tblBox02.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox02.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox02.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox02.Controls.Add(this.btn06, 0, 0);
            this.tblBox02.Controls.Add(this.btn07, 1, 0);
            this.tblBox02.Controls.Add(this.btn08, 2, 0);
            this.tblBox02.Controls.Add(this.btn18, 2, 1);
            this.tblBox02.Controls.Add(this.btn28, 2, 2);
            this.tblBox02.Controls.Add(this.btn27, 1, 2);
            this.tblBox02.Controls.Add(this.btn26, 0, 2);
            this.tblBox02.Controls.Add(this.btn16, 0, 1);
            this.tblBox02.Controls.Add(this.btn17, 1, 1);
            this.tblBox02.Location = new System.Drawing.Point(3, 3);
            this.tblBox02.Name = "tblBox02";
            this.tblBox02.RowCount = 3;
            this.tblBox02.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox02.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox02.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox02.Size = new System.Drawing.Size(192, 192);
            this.tblBox02.TabIndex = 0;
            // 
            // btn06
            // 
            this.btn06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn06.Location = new System.Drawing.Point(4, 4);
            this.btn06.Name = "btn06";
            this.btn06.Size = new System.Drawing.Size(56, 56);
            this.btn06.TabIndex = 0;
            this.btn06.UseVisualStyleBackColor = true;
            this.btn06.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn07
            // 
            this.btn07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn07.Location = new System.Drawing.Point(67, 4);
            this.btn07.Name = "btn07";
            this.btn07.Size = new System.Drawing.Size(56, 56);
            this.btn07.TabIndex = 0;
            this.btn07.UseVisualStyleBackColor = true;
            this.btn07.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn08
            // 
            this.btn08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn08.Location = new System.Drawing.Point(130, 4);
            this.btn08.Name = "btn08";
            this.btn08.Size = new System.Drawing.Size(58, 56);
            this.btn08.TabIndex = 0;
            this.btn08.UseVisualStyleBackColor = true;
            this.btn08.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn18
            // 
            this.btn18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn18.Location = new System.Drawing.Point(130, 67);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(58, 56);
            this.btn18.TabIndex = 0;
            this.btn18.UseVisualStyleBackColor = true;
            this.btn18.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn28
            // 
            this.btn28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn28.Location = new System.Drawing.Point(130, 130);
            this.btn28.Name = "btn28";
            this.btn28.Size = new System.Drawing.Size(58, 58);
            this.btn28.TabIndex = 0;
            this.btn28.UseVisualStyleBackColor = true;
            this.btn28.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn27
            // 
            this.btn27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn27.Location = new System.Drawing.Point(67, 130);
            this.btn27.Name = "btn27";
            this.btn27.Size = new System.Drawing.Size(56, 58);
            this.btn27.TabIndex = 0;
            this.btn27.UseVisualStyleBackColor = true;
            this.btn27.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn26
            // 
            this.btn26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn26.Location = new System.Drawing.Point(4, 130);
            this.btn26.Name = "btn26";
            this.btn26.Size = new System.Drawing.Size(56, 58);
            this.btn26.TabIndex = 0;
            this.btn26.UseVisualStyleBackColor = true;
            this.btn26.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn16
            // 
            this.btn16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn16.Location = new System.Drawing.Point(4, 67);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(56, 56);
            this.btn16.TabIndex = 0;
            this.btn16.UseVisualStyleBackColor = true;
            this.btn16.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn17
            // 
            this.btn17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn17.Location = new System.Drawing.Point(67, 67);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(56, 56);
            this.btn17.TabIndex = 0;
            this.btn17.UseVisualStyleBackColor = true;
            this.btn17.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox10
            // 
            this.tblBox10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox10.ColumnCount = 3;
            this.tblBox10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox10.Controls.Add(this.btn30, 0, 0);
            this.tblBox10.Controls.Add(this.btn52, 2, 2);
            this.tblBox10.Controls.Add(this.btn32, 2, 0);
            this.tblBox10.Controls.Add(this.btn31, 1, 0);
            this.tblBox10.Controls.Add(this.btn41, 1, 1);
            this.tblBox10.Controls.Add(this.btn40, 0, 1);
            this.tblBox10.Controls.Add(this.btn50, 0, 2);
            this.tblBox10.Controls.Add(this.btn51, 1, 2);
            this.tblBox10.Controls.Add(this.btn42, 2, 1);
            this.tblBox10.Location = new System.Drawing.Point(3, 599);
            this.tblBox10.Name = "tblBox10";
            this.tblBox10.RowCount = 3;
            this.tblBox10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox10.Size = new System.Drawing.Size(192, 14);
            this.tblBox10.TabIndex = 0;
            // 
            // btn30
            // 
            this.btn30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn30.Location = new System.Drawing.Point(4, 4);
            this.btn30.Name = "btn30";
            this.btn30.Size = new System.Drawing.Size(56, 1);
            this.btn30.TabIndex = 0;
            this.btn30.UseVisualStyleBackColor = true;
            this.btn30.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn52
            // 
            this.btn52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn52.Location = new System.Drawing.Point(130, 12);
            this.btn52.Name = "btn52";
            this.btn52.Size = new System.Drawing.Size(58, 1);
            this.btn52.TabIndex = 0;
            this.btn52.UseVisualStyleBackColor = true;
            this.btn52.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn32
            // 
            this.btn32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn32.Location = new System.Drawing.Point(130, 4);
            this.btn32.Name = "btn32";
            this.btn32.Size = new System.Drawing.Size(58, 1);
            this.btn32.TabIndex = 0;
            this.btn32.UseVisualStyleBackColor = true;
            this.btn32.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn31
            // 
            this.btn31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn31.Location = new System.Drawing.Point(67, 4);
            this.btn31.Name = "btn31";
            this.btn31.Size = new System.Drawing.Size(56, 1);
            this.btn31.TabIndex = 0;
            this.btn31.UseVisualStyleBackColor = true;
            this.btn31.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn41
            // 
            this.btn41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn41.Location = new System.Drawing.Point(67, 8);
            this.btn41.Name = "btn41";
            this.btn41.Size = new System.Drawing.Size(56, 1);
            this.btn41.TabIndex = 0;
            this.btn41.UseVisualStyleBackColor = true;
            this.btn41.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn40
            // 
            this.btn40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn40.Location = new System.Drawing.Point(4, 8);
            this.btn40.Name = "btn40";
            this.btn40.Size = new System.Drawing.Size(56, 1);
            this.btn40.TabIndex = 0;
            this.btn40.UseVisualStyleBackColor = true;
            this.btn40.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn50
            // 
            this.btn50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn50.Location = new System.Drawing.Point(4, 12);
            this.btn50.Name = "btn50";
            this.btn50.Size = new System.Drawing.Size(56, 1);
            this.btn50.TabIndex = 0;
            this.btn50.UseVisualStyleBackColor = true;
            this.btn50.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn51
            // 
            this.btn51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn51.Location = new System.Drawing.Point(67, 12);
            this.btn51.Name = "btn51";
            this.btn51.Size = new System.Drawing.Size(56, 1);
            this.btn51.TabIndex = 0;
            this.btn51.UseVisualStyleBackColor = true;
            this.btn51.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn42
            // 
            this.btn42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn42.Location = new System.Drawing.Point(130, 8);
            this.btn42.Name = "btn42";
            this.btn42.Size = new System.Drawing.Size(58, 1);
            this.btn42.TabIndex = 0;
            this.btn42.UseVisualStyleBackColor = true;
            this.btn42.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox20
            // 
            this.tblBox20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox20.ColumnCount = 3;
            this.tblBox20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox20.Controls.Add(this.btn82, 2, 2);
            this.tblBox20.Controls.Add(this.btn81, 1, 2);
            this.tblBox20.Controls.Add(this.btn80, 0, 2);
            this.tblBox20.Controls.Add(this.btn70, 0, 1);
            this.tblBox20.Controls.Add(this.btn60, 0, 0);
            this.tblBox20.Controls.Add(this.btn61, 1, 0);
            this.tblBox20.Controls.Add(this.btn62, 2, 0);
            this.tblBox20.Controls.Add(this.btn72, 2, 1);
            this.tblBox20.Controls.Add(this.btn71, 1, 1);
            this.tblBox20.Location = new System.Drawing.Point(3, 539);
            this.tblBox20.Name = "tblBox20";
            this.tblBox20.RowCount = 3;
            this.tblBox20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox20.Size = new System.Drawing.Size(192, 14);
            this.tblBox20.TabIndex = 0;
            // 
            // btn82
            // 
            this.btn82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn82.Location = new System.Drawing.Point(130, 12);
            this.btn82.Name = "btn82";
            this.btn82.Size = new System.Drawing.Size(58, 1);
            this.btn82.TabIndex = 0;
            this.btn82.UseVisualStyleBackColor = true;
            this.btn82.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn81
            // 
            this.btn81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn81.Location = new System.Drawing.Point(67, 12);
            this.btn81.Name = "btn81";
            this.btn81.Size = new System.Drawing.Size(56, 1);
            this.btn81.TabIndex = 0;
            this.btn81.UseVisualStyleBackColor = true;
            this.btn81.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn80
            // 
            this.btn80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn80.Location = new System.Drawing.Point(4, 12);
            this.btn80.Name = "btn80";
            this.btn80.Size = new System.Drawing.Size(56, 1);
            this.btn80.TabIndex = 0;
            this.btn80.UseVisualStyleBackColor = true;
            this.btn80.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn70
            // 
            this.btn70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn70.Location = new System.Drawing.Point(4, 8);
            this.btn70.Name = "btn70";
            this.btn70.Size = new System.Drawing.Size(56, 1);
            this.btn70.TabIndex = 0;
            this.btn70.UseVisualStyleBackColor = true;
            this.btn70.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn60
            // 
            this.btn60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn60.Location = new System.Drawing.Point(4, 4);
            this.btn60.Name = "btn60";
            this.btn60.Size = new System.Drawing.Size(56, 1);
            this.btn60.TabIndex = 0;
            this.btn60.UseVisualStyleBackColor = true;
            this.btn60.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn61
            // 
            this.btn61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn61.Location = new System.Drawing.Point(67, 4);
            this.btn61.Name = "btn61";
            this.btn61.Size = new System.Drawing.Size(56, 1);
            this.btn61.TabIndex = 0;
            this.btn61.UseVisualStyleBackColor = true;
            this.btn61.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn62
            // 
            this.btn62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn62.Location = new System.Drawing.Point(130, 4);
            this.btn62.Name = "btn62";
            this.btn62.Size = new System.Drawing.Size(58, 1);
            this.btn62.TabIndex = 0;
            this.btn62.UseVisualStyleBackColor = true;
            this.btn62.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn72
            // 
            this.btn72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn72.Location = new System.Drawing.Point(130, 8);
            this.btn72.Name = "btn72";
            this.btn72.Size = new System.Drawing.Size(58, 1);
            this.btn72.TabIndex = 0;
            this.btn72.UseVisualStyleBackColor = true;
            this.btn72.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn71
            // 
            this.btn71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn71.Location = new System.Drawing.Point(67, 8);
            this.btn71.Name = "btn71";
            this.btn71.Size = new System.Drawing.Size(56, 1);
            this.btn71.TabIndex = 0;
            this.btn71.UseVisualStyleBackColor = true;
            this.btn71.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox11
            // 
            this.tblBox11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox11.ColumnCount = 3;
            this.tblBox11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox11.Controls.Add(this.btn53, 0, 2);
            this.tblBox11.Controls.Add(this.btn33, 0, 0);
            this.tblBox11.Controls.Add(this.btn43, 0, 1);
            this.tblBox11.Controls.Add(this.btn34, 1, 0);
            this.tblBox11.Controls.Add(this.btn35, 2, 0);
            this.tblBox11.Controls.Add(this.btn45, 2, 1);
            this.tblBox11.Controls.Add(this.btn44, 1, 1);
            this.tblBox11.Controls.Add(this.btn54, 1, 2);
            this.tblBox11.Controls.Add(this.btn55, 2, 2);
            this.tblBox11.Location = new System.Drawing.Point(3, 579);
            this.tblBox11.Name = "tblBox11";
            this.tblBox11.RowCount = 3;
            this.tblBox11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox11.Size = new System.Drawing.Size(192, 14);
            this.tblBox11.TabIndex = 0;
            // 
            // btn53
            // 
            this.btn53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn53.Location = new System.Drawing.Point(4, 12);
            this.btn53.Name = "btn53";
            this.btn53.Size = new System.Drawing.Size(56, 1);
            this.btn53.TabIndex = 0;
            this.btn53.UseVisualStyleBackColor = true;
            this.btn53.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn33
            // 
            this.btn33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn33.Location = new System.Drawing.Point(4, 4);
            this.btn33.Name = "btn33";
            this.btn33.Size = new System.Drawing.Size(56, 1);
            this.btn33.TabIndex = 0;
            this.btn33.UseVisualStyleBackColor = true;
            this.btn33.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn43
            // 
            this.btn43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn43.Location = new System.Drawing.Point(4, 8);
            this.btn43.Name = "btn43";
            this.btn43.Size = new System.Drawing.Size(56, 1);
            this.btn43.TabIndex = 0;
            this.btn43.UseVisualStyleBackColor = true;
            this.btn43.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn34
            // 
            this.btn34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn34.Location = new System.Drawing.Point(67, 4);
            this.btn34.Name = "btn34";
            this.btn34.Size = new System.Drawing.Size(56, 1);
            this.btn34.TabIndex = 0;
            this.btn34.UseVisualStyleBackColor = true;
            this.btn34.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn35
            // 
            this.btn35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn35.Location = new System.Drawing.Point(130, 4);
            this.btn35.Name = "btn35";
            this.btn35.Size = new System.Drawing.Size(58, 1);
            this.btn35.TabIndex = 0;
            this.btn35.UseVisualStyleBackColor = true;
            this.btn35.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn45
            // 
            this.btn45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn45.Location = new System.Drawing.Point(130, 8);
            this.btn45.Name = "btn45";
            this.btn45.Size = new System.Drawing.Size(58, 1);
            this.btn45.TabIndex = 0;
            this.btn45.UseVisualStyleBackColor = true;
            this.btn45.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn44
            // 
            this.btn44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn44.Location = new System.Drawing.Point(67, 8);
            this.btn44.Name = "btn44";
            this.btn44.Size = new System.Drawing.Size(56, 1);
            this.btn44.TabIndex = 0;
            this.btn44.UseVisualStyleBackColor = true;
            this.btn44.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn54
            // 
            this.btn54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn54.Location = new System.Drawing.Point(67, 12);
            this.btn54.Name = "btn54";
            this.btn54.Size = new System.Drawing.Size(56, 1);
            this.btn54.TabIndex = 0;
            this.btn54.UseVisualStyleBackColor = true;
            this.btn54.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn55
            // 
            this.btn55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn55.Location = new System.Drawing.Point(130, 12);
            this.btn55.Name = "btn55";
            this.btn55.Size = new System.Drawing.Size(58, 1);
            this.btn55.TabIndex = 0;
            this.btn55.UseVisualStyleBackColor = true;
            this.btn55.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox12
            // 
            this.tblBox12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox12.ColumnCount = 3;
            this.tblBox12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox12.Controls.Add(this.btn38, 2, 0);
            this.tblBox12.Controls.Add(this.btn48, 2, 1);
            this.tblBox12.Controls.Add(this.btn58, 2, 2);
            this.tblBox12.Controls.Add(this.btn57, 1, 2);
            this.tblBox12.Controls.Add(this.btn56, 0, 2);
            this.tblBox12.Controls.Add(this.btn46, 0, 1);
            this.tblBox12.Controls.Add(this.btn36, 0, 0);
            this.tblBox12.Controls.Add(this.btn37, 1, 0);
            this.tblBox12.Controls.Add(this.btn47, 1, 1);
            this.tblBox12.Location = new System.Drawing.Point(3, 559);
            this.tblBox12.Name = "tblBox12";
            this.tblBox12.RowCount = 3;
            this.tblBox12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox12.Size = new System.Drawing.Size(192, 14);
            this.tblBox12.TabIndex = 0;
            // 
            // btn38
            // 
            this.btn38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn38.Location = new System.Drawing.Point(130, 4);
            this.btn38.Name = "btn38";
            this.btn38.Size = new System.Drawing.Size(58, 1);
            this.btn38.TabIndex = 0;
            this.btn38.UseVisualStyleBackColor = true;
            this.btn38.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn48
            // 
            this.btn48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn48.Location = new System.Drawing.Point(130, 8);
            this.btn48.Name = "btn48";
            this.btn48.Size = new System.Drawing.Size(58, 1);
            this.btn48.TabIndex = 0;
            this.btn48.UseVisualStyleBackColor = true;
            this.btn48.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn58
            // 
            this.btn58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn58.Location = new System.Drawing.Point(130, 12);
            this.btn58.Name = "btn58";
            this.btn58.Size = new System.Drawing.Size(58, 1);
            this.btn58.TabIndex = 0;
            this.btn58.UseVisualStyleBackColor = true;
            this.btn58.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn57
            // 
            this.btn57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn57.Location = new System.Drawing.Point(67, 12);
            this.btn57.Name = "btn57";
            this.btn57.Size = new System.Drawing.Size(56, 1);
            this.btn57.TabIndex = 0;
            this.btn57.UseVisualStyleBackColor = true;
            this.btn57.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn56
            // 
            this.btn56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn56.Location = new System.Drawing.Point(4, 12);
            this.btn56.Name = "btn56";
            this.btn56.Size = new System.Drawing.Size(56, 1);
            this.btn56.TabIndex = 0;
            this.btn56.UseVisualStyleBackColor = true;
            this.btn56.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn46
            // 
            this.btn46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn46.Location = new System.Drawing.Point(4, 8);
            this.btn46.Name = "btn46";
            this.btn46.Size = new System.Drawing.Size(56, 1);
            this.btn46.TabIndex = 0;
            this.btn46.UseVisualStyleBackColor = true;
            this.btn46.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn36
            // 
            this.btn36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn36.Location = new System.Drawing.Point(4, 4);
            this.btn36.Name = "btn36";
            this.btn36.Size = new System.Drawing.Size(56, 1);
            this.btn36.TabIndex = 0;
            this.btn36.UseVisualStyleBackColor = true;
            this.btn36.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn37
            // 
            this.btn37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn37.Location = new System.Drawing.Point(67, 4);
            this.btn37.Name = "btn37";
            this.btn37.Size = new System.Drawing.Size(56, 1);
            this.btn37.TabIndex = 0;
            this.btn37.UseVisualStyleBackColor = true;
            this.btn37.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn47
            // 
            this.btn47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn47.Location = new System.Drawing.Point(67, 8);
            this.btn47.Name = "btn47";
            this.btn47.Size = new System.Drawing.Size(56, 1);
            this.btn47.TabIndex = 0;
            this.btn47.UseVisualStyleBackColor = true;
            this.btn47.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox21
            // 
            this.tblBox21.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox21.ColumnCount = 3;
            this.tblBox21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox21.Controls.Add(this.btn64, 1, 0);
            this.tblBox21.Controls.Add(this.btn63, 0, 0);
            this.tblBox21.Controls.Add(this.btn65, 2, 0);
            this.tblBox21.Controls.Add(this.btn75, 2, 1);
            this.tblBox21.Controls.Add(this.btn85, 2, 2);
            this.tblBox21.Controls.Add(this.btn84, 1, 2);
            this.tblBox21.Controls.Add(this.btn74, 1, 1);
            this.tblBox21.Controls.Add(this.btn73, 0, 1);
            this.tblBox21.Controls.Add(this.btn83, 0, 2);
            this.tblBox21.Location = new System.Drawing.Point(3, 519);
            this.tblBox21.Name = "tblBox21";
            this.tblBox21.RowCount = 3;
            this.tblBox21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox21.Size = new System.Drawing.Size(192, 14);
            this.tblBox21.TabIndex = 0;
            // 
            // btn64
            // 
            this.btn64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn64.Location = new System.Drawing.Point(67, 4);
            this.btn64.Name = "btn64";
            this.btn64.Size = new System.Drawing.Size(56, 1);
            this.btn64.TabIndex = 0;
            this.btn64.UseVisualStyleBackColor = true;
            this.btn64.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn63
            // 
            this.btn63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn63.Location = new System.Drawing.Point(4, 4);
            this.btn63.Name = "btn63";
            this.btn63.Size = new System.Drawing.Size(56, 1);
            this.btn63.TabIndex = 0;
            this.btn63.UseVisualStyleBackColor = true;
            this.btn63.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn65
            // 
            this.btn65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn65.Location = new System.Drawing.Point(130, 4);
            this.btn65.Name = "btn65";
            this.btn65.Size = new System.Drawing.Size(58, 1);
            this.btn65.TabIndex = 0;
            this.btn65.UseVisualStyleBackColor = true;
            this.btn65.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn75
            // 
            this.btn75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn75.Location = new System.Drawing.Point(130, 8);
            this.btn75.Name = "btn75";
            this.btn75.Size = new System.Drawing.Size(58, 1);
            this.btn75.TabIndex = 0;
            this.btn75.UseVisualStyleBackColor = true;
            this.btn75.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn85
            // 
            this.btn85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn85.Location = new System.Drawing.Point(130, 12);
            this.btn85.Name = "btn85";
            this.btn85.Size = new System.Drawing.Size(58, 1);
            this.btn85.TabIndex = 0;
            this.btn85.UseVisualStyleBackColor = true;
            this.btn85.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn84
            // 
            this.btn84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn84.Location = new System.Drawing.Point(67, 12);
            this.btn84.Name = "btn84";
            this.btn84.Size = new System.Drawing.Size(56, 1);
            this.btn84.TabIndex = 0;
            this.btn84.UseVisualStyleBackColor = true;
            this.btn84.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn74
            // 
            this.btn74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn74.Location = new System.Drawing.Point(67, 8);
            this.btn74.Name = "btn74";
            this.btn74.Size = new System.Drawing.Size(56, 1);
            this.btn74.TabIndex = 0;
            this.btn74.UseVisualStyleBackColor = true;
            this.btn74.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn73
            // 
            this.btn73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn73.Location = new System.Drawing.Point(4, 8);
            this.btn73.Name = "btn73";
            this.btn73.Size = new System.Drawing.Size(56, 1);
            this.btn73.TabIndex = 0;
            this.btn73.UseVisualStyleBackColor = true;
            this.btn73.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn83
            // 
            this.btn83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn83.Location = new System.Drawing.Point(4, 12);
            this.btn83.Name = "btn83";
            this.btn83.Size = new System.Drawing.Size(56, 1);
            this.btn83.TabIndex = 0;
            this.btn83.UseVisualStyleBackColor = true;
            this.btn83.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // tblBox22
            // 
            this.tblBox22.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblBox22.ColumnCount = 3;
            this.tblBox22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox22.Controls.Add(this.btn76, 0, 1);
            this.tblBox22.Controls.Add(this.btn86, 0, 2);
            this.tblBox22.Controls.Add(this.btn78, 2, 1);
            this.tblBox22.Controls.Add(this.btn66, 0, 0);
            this.tblBox22.Controls.Add(this.btn67, 1, 0);
            this.tblBox22.Controls.Add(this.btn68, 2, 0);
            this.tblBox22.Controls.Add(this.btn77, 1, 1);
            this.tblBox22.Controls.Add(this.btn87, 1, 2);
            this.tblBox22.Controls.Add(this.btn88, 2, 2);
            this.tblBox22.Location = new System.Drawing.Point(3, 499);
            this.tblBox22.Name = "tblBox22";
            this.tblBox22.RowCount = 3;
            this.tblBox22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblBox22.Size = new System.Drawing.Size(192, 14);
            this.tblBox22.TabIndex = 0;
            // 
            // btn76
            // 
            this.btn76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn76.Location = new System.Drawing.Point(4, 8);
            this.btn76.Name = "btn76";
            this.btn76.Size = new System.Drawing.Size(56, 1);
            this.btn76.TabIndex = 0;
            this.btn76.UseVisualStyleBackColor = true;
            this.btn76.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn86
            // 
            this.btn86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn86.Location = new System.Drawing.Point(4, 12);
            this.btn86.Name = "btn86";
            this.btn86.Size = new System.Drawing.Size(56, 1);
            this.btn86.TabIndex = 0;
            this.btn86.UseVisualStyleBackColor = true;
            this.btn86.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn78
            // 
            this.btn78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn78.Location = new System.Drawing.Point(130, 8);
            this.btn78.Name = "btn78";
            this.btn78.Size = new System.Drawing.Size(58, 1);
            this.btn78.TabIndex = 0;
            this.btn78.UseVisualStyleBackColor = true;
            this.btn78.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn66
            // 
            this.btn66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn66.Location = new System.Drawing.Point(4, 4);
            this.btn66.Name = "btn66";
            this.btn66.Size = new System.Drawing.Size(56, 1);
            this.btn66.TabIndex = 0;
            this.btn66.UseVisualStyleBackColor = true;
            this.btn66.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn67
            // 
            this.btn67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn67.Location = new System.Drawing.Point(67, 4);
            this.btn67.Name = "btn67";
            this.btn67.Size = new System.Drawing.Size(56, 1);
            this.btn67.TabIndex = 0;
            this.btn67.UseVisualStyleBackColor = true;
            this.btn67.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn68
            // 
            this.btn68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn68.Location = new System.Drawing.Point(130, 4);
            this.btn68.Name = "btn68";
            this.btn68.Size = new System.Drawing.Size(58, 1);
            this.btn68.TabIndex = 0;
            this.btn68.UseVisualStyleBackColor = true;
            this.btn68.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn77
            // 
            this.btn77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn77.Location = new System.Drawing.Point(67, 8);
            this.btn77.Name = "btn77";
            this.btn77.Size = new System.Drawing.Size(56, 1);
            this.btn77.TabIndex = 0;
            this.btn77.UseVisualStyleBackColor = true;
            this.btn77.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn87
            // 
            this.btn87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn87.Location = new System.Drawing.Point(67, 12);
            this.btn87.Name = "btn87";
            this.btn87.Size = new System.Drawing.Size(56, 1);
            this.btn87.TabIndex = 0;
            this.btn87.UseVisualStyleBackColor = true;
            this.btn87.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // btn88
            // 
            this.btn88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn88.Location = new System.Drawing.Point(130, 12);
            this.btn88.Name = "btn88";
            this.btn88.Size = new System.Drawing.Size(58, 1);
            this.btn88.TabIndex = 0;
            this.btn88.UseVisualStyleBackColor = true;
            this.btn88.Click += new System.EventHandler(this.btnCell_Click);
            // 
            // pnlNumbers
            // 
            this.pnlNumbers.Controls.Add(this.tblNumbers);
            this.pnlNumbers.Location = new System.Drawing.Point(65, 741);
            this.pnlNumbers.Name = "pnlNumbers";
            this.pnlNumbers.Size = new System.Drawing.Size(612, 68);
            this.pnlNumbers.TabIndex = 1;
            // 
            // tblNumbers
            // 
            this.tblNumbers.ColumnCount = 9;
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tblNumbers.Controls.Add(this.btnNumber1, 0, 0);
            this.tblNumbers.Controls.Add(this.btnNumber2, 1, 0);
            this.tblNumbers.Controls.Add(this.btnNumber3, 2, 0);
            this.tblNumbers.Controls.Add(this.btnNumber4, 3, 0);
            this.tblNumbers.Controls.Add(this.btnNumber5, 4, 0);
            this.tblNumbers.Controls.Add(this.btnNumber6, 5, 0);
            this.tblNumbers.Controls.Add(this.btnNumber7, 6, 0);
            this.tblNumbers.Controls.Add(this.btnNumber8, 7, 0);
            this.tblNumbers.Controls.Add(this.btnNumber9, 8, 0);
            this.tblNumbers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblNumbers.Location = new System.Drawing.Point(0, 0);
            this.tblNumbers.Name = "tblNumbers";
            this.tblNumbers.RowCount = 1;
            this.tblNumbers.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblNumbers.Size = new System.Drawing.Size(612, 68);
            this.tblNumbers.TabIndex = 0;
            // 
            // btnNumber1
            // 
            this.btnNumber1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber1.Location = new System.Drawing.Point(3, 3);
            this.btnNumber1.Name = "btnNumber1";
            this.btnNumber1.Size = new System.Drawing.Size(62, 62);
            this.btnNumber1.TabIndex = 0;
            this.btnNumber1.Text = "1";
            this.btnNumber1.UseVisualStyleBackColor = true;
            this.btnNumber1.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber2
            // 
            this.btnNumber2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber2.Location = new System.Drawing.Point(71, 3);
            this.btnNumber2.Name = "btnNumber2";
            this.btnNumber2.Size = new System.Drawing.Size(62, 62);
            this.btnNumber2.TabIndex = 1;
            this.btnNumber2.Text = "2";
            this.btnNumber2.UseVisualStyleBackColor = true;
            this.btnNumber2.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber3
            // 
            this.btnNumber3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber3.Location = new System.Drawing.Point(139, 3);
            this.btnNumber3.Name = "btnNumber3";
            this.btnNumber3.Size = new System.Drawing.Size(62, 62);
            this.btnNumber3.TabIndex = 2;
            this.btnNumber3.Text = "3";
            this.btnNumber3.UseVisualStyleBackColor = true;
            this.btnNumber3.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber4
            // 
            this.btnNumber4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber4.Location = new System.Drawing.Point(207, 3);
            this.btnNumber4.Name = "btnNumber4";
            this.btnNumber4.Size = new System.Drawing.Size(62, 62);
            this.btnNumber4.TabIndex = 2;
            this.btnNumber4.Text = "4";
            this.btnNumber4.UseVisualStyleBackColor = true;
            this.btnNumber4.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber5
            // 
            this.btnNumber5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber5.Location = new System.Drawing.Point(275, 3);
            this.btnNumber5.Name = "btnNumber5";
            this.btnNumber5.Size = new System.Drawing.Size(62, 62);
            this.btnNumber5.TabIndex = 2;
            this.btnNumber5.Text = "5";
            this.btnNumber5.UseVisualStyleBackColor = true;
            this.btnNumber5.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber6
            // 
            this.btnNumber6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber6.Location = new System.Drawing.Point(343, 3);
            this.btnNumber6.Name = "btnNumber6";
            this.btnNumber6.Size = new System.Drawing.Size(62, 62);
            this.btnNumber6.TabIndex = 2;
            this.btnNumber6.Text = "6";
            this.btnNumber6.UseVisualStyleBackColor = true;
            this.btnNumber6.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber7
            // 
            this.btnNumber7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber7.Location = new System.Drawing.Point(411, 3);
            this.btnNumber7.Name = "btnNumber7";
            this.btnNumber7.Size = new System.Drawing.Size(62, 62);
            this.btnNumber7.TabIndex = 2;
            this.btnNumber7.Text = "7";
            this.btnNumber7.UseVisualStyleBackColor = true;
            this.btnNumber7.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber8
            // 
            this.btnNumber8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber8.Location = new System.Drawing.Point(479, 3);
            this.btnNumber8.Name = "btnNumber8";
            this.btnNumber8.Size = new System.Drawing.Size(62, 62);
            this.btnNumber8.TabIndex = 2;
            this.btnNumber8.Text = "8";
            this.btnNumber8.UseVisualStyleBackColor = true;
            this.btnNumber8.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnNumber9
            // 
            this.btnNumber9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNumber9.Location = new System.Drawing.Point(547, 3);
            this.btnNumber9.Name = "btnNumber9";
            this.btnNumber9.Size = new System.Drawing.Size(62, 62);
            this.btnNumber9.TabIndex = 2;
            this.btnNumber9.Text = "9";
            this.btnNumber9.UseVisualStyleBackColor = true;
            this.btnNumber9.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // lblMode
            // 
            this.lblMode.AutoSize = true;
            this.lblMode.Location = new System.Drawing.Point(50, 43);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(122, 25);
            this.lblMode.TabIndex = 2;
            this.lblMode.Text = "Chế Độ: Dễ";
            // 
            // lblLives
            // 
            this.lblLives.Location = new System.Drawing.Point(288, 43);
            this.lblLives.Name = "lblLives";
            this.lblLives.Size = new System.Drawing.Size(174, 30);
            this.lblLives.TabIndex = 2;
            this.lblLives.Text = "Mạng:   ♥ ♥ ♥";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(510, 43);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(167, 25);
            this.lblTime.TabIndex = 2;
            this.lblTime.Text = "Thời gian: 00:00";
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 1000;
            this.gameTimer.Tick += new System.EventHandler(this.gameTimer_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.tblBox02, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tblBox01, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tblBox22, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tblBox21, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tblBox20, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.tblBox12, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.tblBox11, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.tblBox10, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.tblBox00, 0, 8);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(35, 90);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(668, 636);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // frmGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(892, 863);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblLives);
            this.Controls.Add(this.lblMode);
            this.Controls.Add(this.pnlNumbers);
            this.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SUDOKU";
            this.tblBox00.ResumeLayout(false);
            this.tblBox01.ResumeLayout(false);
            this.tblBox02.ResumeLayout(false);
            this.tblBox10.ResumeLayout(false);
            this.tblBox20.ResumeLayout(false);
            this.tblBox11.ResumeLayout(false);
            this.tblBox12.ResumeLayout(false);
            this.tblBox21.ResumeLayout(false);
            this.tblBox22.ResumeLayout(false);
            this.pnlNumbers.ResumeLayout(false);
            this.tblNumbers.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblBox00;
        private System.Windows.Forms.TableLayoutPanel tblBox01;
        private System.Windows.Forms.TableLayoutPanel tblBox02;
        private System.Windows.Forms.TableLayoutPanel tblBox10;
        private System.Windows.Forms.TableLayoutPanel tblBox20;
        private System.Windows.Forms.TableLayoutPanel tblBox11;
        private System.Windows.Forms.TableLayoutPanel tblBox12;
        private System.Windows.Forms.TableLayoutPanel tblBox21;
        private System.Windows.Forms.TableLayoutPanel tblBox22;
        private System.Windows.Forms.Button btn00;
        private System.Windows.Forms.Button btn01;
        private System.Windows.Forms.Button btn02;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn20;
        private System.Windows.Forms.Button btn21;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Button btn23;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn03;
        private System.Windows.Forms.Button btn04;
        private System.Windows.Forms.Button btn05;
        private System.Windows.Forms.Button btn15;
        private System.Windows.Forms.Button btn25;
        private System.Windows.Forms.Button btn24;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn06;
        private System.Windows.Forms.Button btn07;
        private System.Windows.Forms.Button btn08;
        private System.Windows.Forms.Button btn18;
        private System.Windows.Forms.Button btn28;
        private System.Windows.Forms.Button btn27;
        private System.Windows.Forms.Button btn26;
        private System.Windows.Forms.Button btn16;
        private System.Windows.Forms.Button btn17;
        private System.Windows.Forms.Button btn30;
        private System.Windows.Forms.Button btn52;
        private System.Windows.Forms.Button btn32;
        private System.Windows.Forms.Button btn31;
        private System.Windows.Forms.Button btn41;
        private System.Windows.Forms.Button btn40;
        private System.Windows.Forms.Button btn50;
        private System.Windows.Forms.Button btn51;
        private System.Windows.Forms.Button btn42;
        private System.Windows.Forms.Button btn82;
        private System.Windows.Forms.Button btn81;
        private System.Windows.Forms.Button btn80;
        private System.Windows.Forms.Button btn70;
        private System.Windows.Forms.Button btn60;
        private System.Windows.Forms.Button btn61;
        private System.Windows.Forms.Button btn62;
        private System.Windows.Forms.Button btn72;
        private System.Windows.Forms.Button btn71;
        private System.Windows.Forms.Button btn53;
        private System.Windows.Forms.Button btn33;
        private System.Windows.Forms.Button btn43;
        private System.Windows.Forms.Button btn34;
        private System.Windows.Forms.Button btn35;
        private System.Windows.Forms.Button btn45;
        private System.Windows.Forms.Button btn44;
        private System.Windows.Forms.Button btn54;
        private System.Windows.Forms.Button btn55;
        private System.Windows.Forms.Button btn38;
        private System.Windows.Forms.Button btn48;
        private System.Windows.Forms.Button btn58;
        private System.Windows.Forms.Button btn57;
        private System.Windows.Forms.Button btn56;
        private System.Windows.Forms.Button btn46;
        private System.Windows.Forms.Button btn36;
        private System.Windows.Forms.Button btn37;
        private System.Windows.Forms.Button btn47;
        private System.Windows.Forms.Button btn64;
        private System.Windows.Forms.Button btn63;
        private System.Windows.Forms.Button btn65;
        private System.Windows.Forms.Button btn75;
        private System.Windows.Forms.Button btn85;
        private System.Windows.Forms.Button btn84;
        private System.Windows.Forms.Button btn74;
        private System.Windows.Forms.Button btn73;
        private System.Windows.Forms.Button btn83;
        private System.Windows.Forms.Button btn76;
        private System.Windows.Forms.Button btn86;
        private System.Windows.Forms.Button btn78;
        private System.Windows.Forms.Button btn66;
        private System.Windows.Forms.Button btn67;
        private System.Windows.Forms.Button btn68;
        private System.Windows.Forms.Button btn77;
        private System.Windows.Forms.Button btn87;
        private System.Windows.Forms.Button btn88;
        private System.Windows.Forms.Panel pnlNumbers;
        private System.Windows.Forms.TableLayoutPanel tblNumbers;
        private System.Windows.Forms.Button btnNumber1;
        private System.Windows.Forms.Button btnNumber2;
        private System.Windows.Forms.Button btnNumber3;
        private System.Windows.Forms.Button btnNumber4;
        private System.Windows.Forms.Button btnNumber5;
        private System.Windows.Forms.Button btnNumber6;
        private System.Windows.Forms.Button btnNumber7;
        private System.Windows.Forms.Button btnNumber8;
        private System.Windows.Forms.Button btnNumber9;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.Label lblLives;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}